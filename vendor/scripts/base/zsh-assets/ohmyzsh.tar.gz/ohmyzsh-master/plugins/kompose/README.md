# kompose

This plugin provides completion for [kompose](https://github.com/kubernetes/kompose),
to migrate from docker compose to Kubernetes resource definitions.

To use it, add `kompose` to the plugins array in your zshrc file.

```
plugins=(... kompose)
```

**Author:** [@kevinkirkup](https://github.com/kevinkirkup)
